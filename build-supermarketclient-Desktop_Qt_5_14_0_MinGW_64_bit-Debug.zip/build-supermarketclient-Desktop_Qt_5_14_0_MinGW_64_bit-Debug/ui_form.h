/********************************************************************************
** Form generated from reading UI file 'form.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM_H
#define UI_FORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_form
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *nameLabel;
    QLabel *label_2;
    QLabel *numberLabel;
    QLabel *label_4;
    QLabel *unitPriceLabel;

    void setupUi(QMainWindow *form)
    {
        if (form->objectName().isEmpty())
            form->setObjectName(QString::fromUtf8("form"));
        form->resize(820, 60);
        centralwidget = new QWidget(form);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 0, 821, 61));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(true);

        horizontalLayout->addWidget(label);

        nameLabel = new QLabel(layoutWidget);
        nameLabel->setObjectName(QString::fromUtf8("nameLabel"));

        horizontalLayout->addWidget(nameLabel);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        numberLabel = new QLabel(layoutWidget);
        numberLabel->setObjectName(QString::fromUtf8("numberLabel"));

        horizontalLayout->addWidget(numberLabel);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout->addWidget(label_4);

        unitPriceLabel = new QLabel(layoutWidget);
        unitPriceLabel->setObjectName(QString::fromUtf8("unitPriceLabel"));

        horizontalLayout->addWidget(unitPriceLabel);

        form->setCentralWidget(centralwidget);

        retranslateUi(form);

        QMetaObject::connectSlotsByName(form);
    } // setupUi

    void retranslateUi(QMainWindow *form)
    {
        form->setWindowTitle(QCoreApplication::translate("form", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("form", "  \345\225\206\345\223\201:", nullptr));
        nameLabel->setText(QCoreApplication::translate("form", "TextLabel", nullptr));
        label_2->setText(QCoreApplication::translate("form", "\345\272\223\345\255\230:", nullptr));
        numberLabel->setText(QCoreApplication::translate("form", "TextLabel", nullptr));
        label_4->setText(QCoreApplication::translate("form", "\345\215\225\344\273\267:", nullptr));
        unitPriceLabel->setText(QCoreApplication::translate("form", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class form: public Ui_form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_H
