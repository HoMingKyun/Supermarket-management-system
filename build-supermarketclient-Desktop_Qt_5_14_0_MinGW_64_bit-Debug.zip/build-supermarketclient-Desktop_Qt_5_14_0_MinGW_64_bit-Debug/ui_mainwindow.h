/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *widget;
    QPushButton *registerbtn;
    QPushButton *loginbtn;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *daylabel;
    QLabel *weeklabel;
    QLabel *timelabel;
    QWidget *tab_5;
    QTextBrowser *textBrowser;
    QLineEdit *sendEdit;
    QPushButton *sendbtn;
    QWidget *tab_2;
    QWidget *camerawidget;
    QWidget *tab_3;
    QListWidget *listWidget;
    QWidget *tab_4;
    QSpinBox *spinBox;
    QComboBox *comboBox;
    QLabel *label_2;
    QPushButton *addgoodsbtn;
    QTableWidget *tableWidget;
    QLabel *label;
    QLabel *moneylabel;
    QPushButton *buybtn;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 480);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 801, 480));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        widget = new QWidget(tab);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 711, 411));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        registerbtn = new QPushButton(tab);
        registerbtn->setObjectName(QString::fromUtf8("registerbtn"));
        registerbtn->setGeometry(QRect(120, 410, 111, 41));
        loginbtn = new QPushButton(tab);
        loginbtn->setObjectName(QString::fromUtf8("loginbtn"));
        loginbtn->setGeometry(QRect(0, 410, 121, 41));
        layoutWidget = new QWidget(tab);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(250, 410, 451, 41));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        daylabel = new QLabel(layoutWidget);
        daylabel->setObjectName(QString::fromUtf8("daylabel"));

        horizontalLayout->addWidget(daylabel);

        weeklabel = new QLabel(layoutWidget);
        weeklabel->setObjectName(QString::fromUtf8("weeklabel"));

        horizontalLayout->addWidget(weeklabel);

        timelabel = new QLabel(layoutWidget);
        timelabel->setObjectName(QString::fromUtf8("timelabel"));

        horizontalLayout->addWidget(timelabel);

        tabWidget->addTab(tab, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        textBrowser = new QTextBrowser(tab_5);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(0, 0, 801, 401));
        sendEdit = new QLineEdit(tab_5);
        sendEdit->setObjectName(QString::fromUtf8("sendEdit"));
        sendEdit->setGeometry(QRect(0, 400, 691, 61));
        sendbtn = new QPushButton(tab_5);
        sendbtn->setObjectName(QString::fromUtf8("sendbtn"));
        sendbtn->setGeometry(QRect(690, 400, 111, 61));
        tabWidget->addTab(tab_5, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        camerawidget = new QWidget(tab_2);
        camerawidget->setObjectName(QString::fromUtf8("camerawidget"));
        camerawidget->setGeometry(QRect(0, 0, 801, 451));
        camerawidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        listWidget = new QListWidget(tab_3);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(0, 0, 801, 461));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        spinBox = new QSpinBox(tab_4);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(340, 410, 81, 41));
        spinBox->setMinimum(1);
        spinBox->setMaximum(999);
        comboBox = new QComboBox(tab_4);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(70, 410, 141, 31));
        label_2 = new QLabel(tab_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 410, 71, 41));
        addgoodsbtn = new QPushButton(tab_4);
        addgoodsbtn->setObjectName(QString::fromUtf8("addgoodsbtn"));
        addgoodsbtn->setGeometry(QRect(430, 410, 121, 41));
        tableWidget = new QTableWidget(tab_4);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(0, 0, 811, 401));
        tableWidget->horizontalHeader()->setDefaultSectionSize(150);
        label = new QLabel(tab_4);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(0, 410, 111, 41));
        moneylabel = new QLabel(tab_4);
        moneylabel->setObjectName(QString::fromUtf8("moneylabel"));
        moneylabel->setGeometry(QRect(660, 410, 131, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        font.setPointSize(14);
        moneylabel->setFont(font);
        buybtn = new QPushButton(tab_4);
        buybtn->setObjectName(QString::fromUtf8("buybtn"));
        buybtn->setGeometry(QRect(562, 410, 91, 41));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(14);
        buybtn->setFont(font1);
        tabWidget->addTab(tab_4, QString());
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        registerbtn->setText(QCoreApplication::translate("MainWindow", "\346\263\250\345\206\214", nullptr));
        loginbtn->setText(QCoreApplication::translate("MainWindow", "\347\231\273\351\231\206", nullptr));
        daylabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        weeklabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        timelabel->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "\345\271\277\345\221\212", nullptr));
        sendbtn->setText(QCoreApplication::translate("MainWindow", " \345\217\221\351\200\201", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QCoreApplication::translate("MainWindow", "\345\234\250\347\272\277\345\222\250\350\257\242", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", " \347\233\221\346\216\247", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "\346\265\217\350\247\210\345\225\206\345\223\201", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\346\225\260\351\207\217", nullptr));
        addgoodsbtn->setText(QCoreApplication::translate("MainWindow", "\346\267\273\345\212\240\345\210\260\350\264\255\347\211\251\350\275\246", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "\345\225\206\345\223\201", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "\346\225\260\347\233\256", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "\345\215\225\344\273\267", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "\345\220\210\350\256\241", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "   \350\264\255\347\211\251\350\275\246", nullptr));
        moneylabel->setText(QCoreApplication::translate("MainWindow", "0\345\205\203", nullptr));
        buybtn->setText(QCoreApplication::translate("MainWindow", "\347\273\223\347\256\227", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("MainWindow", "\350\264\255\344\271\260\345\225\206\345\223\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
