#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDateTime>
#include <QVBoxLayout>
#include <QFile>
#include <QtDebug>
#include <QVideoWidget>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("客户端操作界面");

    //[1] 客户向服务器发送连接请求
    socket.connectToHost("192.168.31.210",6666);
    //[3]建立与服务端读取数据的信号和槽,并且读取服务器数据
    connect(&socket,&QTcpSocket::readyRead,this,&MainWindow::readData);


    QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    foreach (const QCameraInfo &cameraInfo, cameras) {
        if (cameraInfo.description() == "USB2.0 PC CAMERA")
            camera = new QCamera(cameraInfo);
    }
    camerashow();
    //时间
    connect(&timer,&QTimer::timeout,this,&MainWindow::getTime);
    timer.start(1000);
    //广告
    connect(&process,SIGNAL(finished(int,QProcess::ExitStatus)),this,SLOT(advertisement()));
      advertisement();

      connect(&r,SIGNAL(accountPasswrod(QString)),this,SLOT(sendAccountPasswd(QString)));
      connect(&l,SIGNAL(accountPasswd(QString)),this,SLOT(sendAccountPasswd(QString)));
      connect(this,SIGNAL(registrationFeedback(QString)),&r,SLOT(receivingFeedback(QString)));
      connect(this,SIGNAL(loginFeedback(QString)),&l,SLOT(receivingFeedback(QString)));
      connect(&r,SIGNAL(returnMainWindow()),this,SLOT(showWindowL()));
      connect(&l,SIGNAL(returnMainWindow(QString)),this,SLOT(showWindow(QString)));

    //新建一个超市商品数据库
    db =  QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("market.db");

    if(!db.open())
    {

        qDebug() << "open failed database" << db.lastError();
    }
    QSqlQuery query;
    QString tablesql = QString("create table goods ("
                               "id integer PRIMARY KEY autoincrement,"
                               "name text not null,"
                               "number int not null,"
                               "unitPrice double not null);");

    //判断数据库是否有某个表，
     if(!db.tables().contains("goods"))
     {
         if(!query.exec(tablesql))
         {
             qDebug() << "create failed table" << db.lastError();
         }


     }else
     {
           qDebug() << "goods table is in db";
     }
     viewGoods();
    refreshComboBoxData();


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::camerashow()
{

    //给照相机的画面显示控件
    QCameraViewfinder *viewfinder = new QCameraViewfinder(ui->camerawidget);
    viewfinder->resize(800,480);
    camera->setViewfinder(viewfinder);
     viewfinder->show();
     camera->start();
}

void MainWindow::getTime()
{

    QDateTime current_time =QDateTime::currentDateTime();
    ui->daylabel->setText(current_time.toString("yyyy.MM.dd"));
    ui->timelabel->setText(current_time.toString("hh:mm:ss"));
    ui->weeklabel->setText(current_time.toString("ddd"));
}

void MainWindow::advertisement()
{
       QStringList fileName;
    fileName << "./1.mp4";
    fileName << "./2.mp4";
    fileName << "./3.mp4";

    //创建一个带文件的播放参数列表
    QStringList argments;
    // mplayer -slave -quiet -wid 窗口id号 媒体的路径
    argments << "-slave" << "-quiet" << "-wid"
             <<QString::number(ui->widget->winId())  << fileName.at(i);
    //利用进程来启动第三方播放器进行播放
    process.start("./mplayer/mplayer.exe",argments);
    i++;
    if(i == 3)
        i = 0;
}

void MainWindow::on_loginbtn_clicked()
{
    l.show();
    this->hide();
}

void MainWindow::on_registerbtn_clicked()
{
    r.show();
    this->hide();
}

void MainWindow::sendAccountPasswd(QString str)
{
     socket.write(str.toUtf8());
}

void MainWindow::showWindow(QString str)
{
    if(str == "YES")
        isOk = true;
    this->show();
}

void MainWindow::showWindowL()
{
    this->show();
}

void MainWindow::viewGoods()
{
    ui->listWidget->clear();
    QSqlQuery query;
    query.exec("select * from goods");

    while(query.next())
        {
        QString name = query.value("name").toString();
        int number = query.value("number").toInt();
        double unitPrice = query.value("unitPrice").toDouble();

        form* mform = new form();
        mform->formInfo(name,number,unitPrice);
        QListWidgetItem* item = new QListWidgetItem();
        item->setSizeHint(QSize(mform->width(),mform->height()));
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item,mform);

    }
}

void MainWindow::on_addgoodsbtn_clicked()
{
    if(isOk == false)
    {
        QMessageBox::warning(this,"警告","还未登录!");
        return;
    }

    QSqlQuery query;
    QString str = QString("select * from goods where name = '%1';").arg(ui->comboBox->currentText());
    query.exec(str);

    int number = 0;
    double unitPrice = 0;
    while(query.next())
    {
        number = query.value("number").toInt();
        unitPrice = query.value("unitPrice").toDouble();
    }

    QString sqlUpdate = QString("update goods set number = %1 where name = '%2';")
            .arg(number - ui->spinBox->text().toInt()).arg(ui->comboBox->currentText());
    qDebug() << number;
    qDebug() << ui->spinBox->text().toInt();
    qDebug() << sqlUpdate;
    if(!query.exec(sqlUpdate))
    {
      qDebug() << "Error:Failed to update" << db.lastError();
    }else{
        qDebug() <<  "update data success";
    }

    double total = ui->spinBox->text().toInt()*unitPrice;

    ui->tableWidget->setColumnCount(4);
    ui->tableWidget->insertRow(ui->tableWidget->rowCount());
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);  //整行选中的方式

    QTableWidgetItem * item1 = new QTableWidgetItem(ui->comboBox->currentText());
    QTableWidgetItem * item2 = new QTableWidgetItem(ui->spinBox->text());
    QTableWidgetItem * item3 = new QTableWidgetItem(QString::number(unitPrice));
    QTableWidgetItem * item4 = new QTableWidgetItem(QString::number(total));

    ui->tableWidget->setItem(ui->tableWidget->rowCount()-1,0,item1);
    ui->tableWidget->setItem(ui->tableWidget->rowCount()-1,1,item2);
    ui->tableWidget->setItem(ui->tableWidget->rowCount()-1,2,item3);
    ui->tableWidget->setItem(ui->tableWidget->rowCount()-1,3,item4);

    money += total;
    ui->moneylabel->setText(QString::number(money) + "元");


}

void MainWindow::on_buybtn_clicked()
{
    QMessageBox::information(this,"结账","结账成功,当次结账共" + QString::number(money) + "元!",
                             QMessageBox::Ok,
                             QMessageBox::Ok);
    money = 0;
    ui->moneylabel->setText(QString::number(money)+ "元");
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(0);
    viewGoods();
}

void MainWindow::refreshComboBoxData()
{
    ui->comboBox->clear();
    QStringList list;
    QSqlQuery query;
    query.exec("select * from goods;");

    while(query.next())
    {
        list << query.value("name").toString();
    }
    ui->comboBox->addItems(list);
}

void MainWindow::on_comboBox_activated(const QString &arg1)
{
    QSqlQuery query;
    QString str = QString("select * from goods where name = '%1';").arg(arg1);
    query.exec(str);
    qDebug() << arg1;
    while(query.next())
    {
        qDebug() << query.value("number").toInt();
        ui->spinBox->setMaximum(query.value("number").toInt());
    }
}

void MainWindow::on_sendbtn_clicked()
{  socket.write(ui->sendEdit->text().toUtf8());
    ui->textBrowser->append("会员：" + ui->sendEdit->text());
    ui->sendEdit->clear();

}

void MainWindow::readData()
{ //读取服务器数据
    QString msg =socket.readAll();
    QStringList list = msg.split("#");
    qDebug() << msg;
    if(list.at(0) == "R")
    {
        emit registrationFeedback(list.at(1));
    }
    else if(list.at(0) == "L")
    {
        emit loginFeedback(list.at(1));
    }else {
        //打印客户端的消息
         ui->textBrowser->append("客服：" + msg);
    }

}

