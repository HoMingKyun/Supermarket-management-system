#ifndef MAINWINDOW_H
#define MAINWINDOW_H


#include <QMainWindow>
//监控
#include <QCamera>
#include <QCameraInfo>
#include <QCameraViewfinder>
//时间
#include <QTimer>
//进程_广告
#include <QProcess>
#include <QMediaPlayer>
#include <QFile>

#include "login.h"
#include "register.h"
#include "form.h"

#include <QTcpSocket>

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void camerashow();

    void getTime();

     void advertisement();

     void on_loginbtn_clicked();

     void on_registerbtn_clicked();

     void sendAccountPasswd(QString str);  //给服务器发送注册或者登录的账号密码

     void showWindow(QString str);

     void showWindowL();

    //浏览商品
    void viewGoods();

    void on_addgoodsbtn_clicked();

    void on_buybtn_clicked();

    void refreshComboBoxData();  //刷新选择清单

     void on_comboBox_activated(const QString &arg1);

     //在线咨询
     void on_sendbtn_clicked();
     void readData();


signals:

       void registrationFeedback(QString str); //给注册界面发去服务器反馈信息

       void loginFeedback(QString str); //给登录界面发去服务器反馈信息

private:
    Ui::MainWindow *ui;
    QCamera* camera;
    QTimer timer;
    QProcess process;
     int i = 0;        //4个广告轮播

    login l;
    Register r;
    bool isOk = false;  //判断是否登录
    QTcpSocket socket;
    QSqlDatabase db;
     double money = 0;  //花费的金额
};
#endif // MAINWINDOW_H
