#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>

namespace Ui {
class login;
}

class login : public QMainWindow
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_loginbtn_clicked();

     void receivingFeedback(QString str);  //接收服务器的反馈信息


signals:
       void accountPasswd(QString str);
     void returnMainWindow(QString str);  //返回主界面


private:
    Ui::login *ui;
};

#endif // LOGIN_H
