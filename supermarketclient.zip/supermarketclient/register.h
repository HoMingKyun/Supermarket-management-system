#ifndef REGISTER_H
#define REGISTER_H

#include <QMainWindow>

namespace Ui {
class Register;
}

class Register : public QMainWindow
{
    Q_OBJECT

public:
    explicit Register(QWidget *parent = nullptr);
    ~Register();


private slots:
    void on_registerbtn_clicked();
  void receivingFeedback(QString str);  //接收服务器的反馈信息

signals:
    void accountPasswrod(QString str);  //给登录界面或注册界面发去判断信息

    void returnMainWindow();


private:
    Ui::Register *ui;
};

#endif // REGISTER_H
