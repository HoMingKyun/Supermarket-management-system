#include "form.h"
#include "ui_form.h"

form::form(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::form)
{
    ui->setupUi(this);
}

form::~form()
{
    delete ui;
}

void form::formInfo(QString name, int number, double price)
{
    ui->nameLabel->setText(name);
    ui->numberLabel->setText(QString::number(number));
    ui->unitPriceLabel->setText(QString::number(price));
}
