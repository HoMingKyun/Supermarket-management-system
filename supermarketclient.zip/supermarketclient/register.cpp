#include "register.h"
#include "ui_register.h"

#include "QMessageBox"
#include "QDebug"
Register::Register(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
      this->setWindowTitle("注册界面");
}

Register::~Register()
{
    delete ui;
}

void Register::on_registerbtn_clicked()
{
    QString str = "R#" + ui->accountlineEdit->text() + "#" + ui->passwordlineEdit->text();
    qDebug() << "registerBtn:" << str;
    emit accountPasswrod(str);
}

void Register::receivingFeedback(QString str)
{

    qDebug() << "receivingFeedback:" << str;
    if(str == "YES")
    {
        QMessageBox::information(this,"窗口","注册成功",
                                 QMessageBox::Ok,
                                 QMessageBox::Ok);
        this->hide();

        emit returnMainWindow();
    }else if(str == "NO")
    {
        QMessageBox::warning(this,"警告","该账户已经注册!");
        qDebug() << "warning:" << str;
    }else{
        qDebug() << "没有注册信息";
    }
}
