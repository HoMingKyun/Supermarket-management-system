#include "login.h"
#include "ui_login.h"

#include "QMessageBox"
#include "QDebug"

login::login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
       this->setWindowTitle("登录界面");
}

login::~login()
{
    delete ui;
}

void login::on_loginbtn_clicked()
{
    QString str = "L#" + ui->accountlineEdit->text() + "#" + ui->passwordlineEdit->text();
    qDebug() << "loginBtn:" << str;
    emit accountPasswd(str);
}

void login::receivingFeedback(QString str)
{
    if(str=="YES")
    {
        QMessageBox::information(this,"登录信息","登录成功!",
                                 QMessageBox::Ok,
                                 QMessageBox::Ok);
        this->hide();
        QString str = "YES";
         emit returnMainWindow(str);

    }
}
