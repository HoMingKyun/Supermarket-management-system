#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
}

Form::~Form()
{
    delete ui;
}

void Form::setformInfo(int id, QString account, QString password)
{
    ui->idlabel->setText(QString::number(id));
    ui->passwordlabel->setText(password);
    ui->accountlabel->setText(account);
}
