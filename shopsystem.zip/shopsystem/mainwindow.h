#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QCamera>
#include <QCameraInfo>
#include <QCameraViewfinder>

#include <QSqlDatabase>  //数据库类
#include <QSqlError>  //数据库出错类
#include <QSqlQuery> // 执行sql语言来访问数据库

#include <QTcpServer>
#include <QTcpSocket>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private:
    void addmember(QString Account,QString Passwork);  //新注册的会员信息到数据库中

private slots:
    void on_pushButton_clicked();   //删除会员
    void refreshData();             //刷新显示数据
    void on_sendbtn_clicked();     //发送给用户信息
    void newClient();  //连接新客户端
    void readData();  //读取客户端发来的数据
    void judgemember(QString Account,QString Password);              //判断登录账号密码

    void registermember(QString Account,QString Password);          //注册账号



    void camerashow();            //监控

private:
    Ui::MainWindow *ui;
    QCamera* camera;
    QSqlDatabase db;
    QTcpServer server;
    QTcpSocket* socket;
};
#endif // MAINWINDOW_H
