#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtDebug>
#include "form.h"
#include <QListWidgetItem>
#include <QVideoWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("管理员界面");

    //[1]获取当前设备信息列表
    QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    foreach (const QCameraInfo &cameraInfo, cameras) {
        qDebug() << cameraInfo.description();
        if (cameraInfo.description() == "USB2.0 PC CAMERA")
            camera = new QCamera(cameraInfo);
        else {
            qDebug() << "can not open camera ";
        }
    }

       camerashow();

      //连接一个数据库，参数一：连接数据库的名字 参数二：连接的名字
      db =  QSqlDatabase::addDatabase("QSQLITE");
      db.setDatabaseName("userinfo.db");
      if(!db.open())
            {

                qDebug() << "open failed database" << db.lastError();
            }
             //创建执行sql语句对象
            QSqlQuery query;
             //构建一条sql语句：在数据库中创建一个表格
            QString tablesql = QString("create table infoform ("
                                       "id integer PRIMARY KEY autoincrement,"
                                       "account text not null,"
                                       "password text not null);");
        //判断数据库是否有某个表
            if(!db.tables().contains("infoform"))
            {
                if(!query.exec(tablesql))
                {
                     qDebug() << "create failed table" << db.lastError();
                }else{
                     qDebug() << "infoform table is in db";
                }
            }

    refreshData();

    //[1] 监听客户端
    server.listen(QHostAddress::Any,6666);

    //[2] 建立新客户端信号相关的槽连接
    connect(&server,&QTcpServer::newConnection,this,&MainWindow::newClient);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::addmember(QString Account, QString Passwork)
{

    QSqlQuery query;
    QString info = QString("insert into infoform(account,password) values('%1','%2');").arg(Account).arg(Passwork);
    qDebug() << "info:" << info;
    query.exec(info);
    refreshData();
}

void MainWindow::on_pushButton_clicked()
{
    QSqlQuery query;
    QString sqldelete = QString("delete from infoform where id=%1")
            .arg(ui->idlineEdit->text().toInt());
    query.exec(sqldelete);
    refreshData();
}

void MainWindow::refreshData()
{
    ui->listWidget->clear();
    QSqlQuery query;
    query.exec("select * from infoform");
      //遍历数据库的数据
    while(query.next())
    {
        int id =query.value("id").toUInt();
        QString account = query.value("account").toString();
        QString password = query.value("password").toString();
        Form* InFoform= new Form();
        InFoform->setformInfo(id,account,password);
        QListWidgetItem* item = new QListWidgetItem;
        item->setSizeHint(QSize(InFoform->width(),InFoform->height()));
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item,InFoform);
    }
}

void MainWindow::on_sendbtn_clicked()
{
    socket->write((ui->sendEdit->text().toUtf8()));
    ui->textBrowser->append("服务端：" + ui->sendEdit->text());
    ui->sendEdit->clear();
}

void MainWindow::newClient()
{
    socket =  server.nextPendingConnection(); //每次都会返回一个新的客户端:比如：张三，李四
    //[3] 在此槽函数中，判断客户端是否向我发送消息，当客户端发送消息时，该客户端会自动送一个信号
    connect(socket,&QTcpSocket::readyRead,this,&MainWindow::readData);
}

void MainWindow::readData()
{
    //[4]要对客户端进行判断，到底是谁给我发送消息
    QTcpSocket* msocket = dynamic_cast<QTcpSocket*> (sender()); //代表任何人
    QString msg = msocket->readAll();
    qDebug() << "管理员收：" << msg;
    QStringList list = msg.split("#");
    if(list.at(0) == "R")
    {
        qDebug() << "管理员R：" << list.at(1) << " " << list.at(2);
        registermember(list.at(1),list.at(2));
    }else if(list.at(0) == "L")
    {
        qDebug() << "管理员L：" << list.at(1) << " " << list.at(2);
        judgemember(list.at(1),list.at(2));
    }else {
        //打印客户端的消息
         ui->textBrowser->append("会员：" + msg);
    }
}

void MainWindow::judgemember(QString Account, QString Password)
{
    QSqlQuery query;
   query.exec("select * from infoform");
    while(query.next())
    {
        QString account = query.value("account").toString();
        QString password = query.value("password").toString();
        if(account==Account && password==Password)
        {
            QString ms1 = "L#YES";
             qDebug() << "管理员L返回登录成功";
            socket->write(ms1.toUtf8());
            return;
        }   
    }
    QString ms2 = "L#NO";
    qDebug() << "管理员L返回登录失败";
   socket->write(ms2.toUtf8());
   return;

}

void MainWindow::registermember(QString Account, QString Password)
{
    QSqlQuery query;
    query.exec("select * from infoform");
    while(query.next())
    {
        QString account = query.value("account").toString();
        QString password = query.value("password").toString();
        if(account==Account)
        {
            qDebug() << "管理员R返回注册失败";
            QString msg1 = "R#NO";
            socket->write(msg1.toUtf8());
            return;
        }
    }
     MainWindow::addmember(Account,Password);
    qDebug() << "管理员R返回注册成功";
    QString msg2 = "R#YES";
    socket->write(msg2.toUtf8());
}

void MainWindow::camerashow()
{
    QCameraViewfinder *viewfinder = new QCameraViewfinder(ui->cameraWidget);
  viewfinder->resize(800,480);

    camera->setViewfinder(viewfinder);
    viewfinder->show();
    camera->start();
}

